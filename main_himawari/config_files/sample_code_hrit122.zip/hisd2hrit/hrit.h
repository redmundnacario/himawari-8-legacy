/**

 HRIT Definition

*/
/***********************************
  2006.03.02  Start
***********************************/

/**
	#0 Primary Header
************************/
typedef struct primaryHeader
	{
	unsigned char hdrType;		/**< Header Type */
	unsigned short recLen;		/**< Header Record Lengh */
	unsigned char typeCode;		/**< File Type Code */
	unsigned long hdrLen;		/**< Total Header Length */
	unsigned long datLen[2];	/**< Data Field Length */
	float fDatLen;				/**< Data Field Length (float) */
	}HritPrimary;

/**
	#1 Image Structure	
************************/
typedef struct
	{
	unsigned char hdrType;	/**< Header Type */
	unsigned short recLen;	/**< Header Record Lengh */
	unsigned char bitPix;	/**< Number of Bits Per Pixel */
	unsigned short nPix;	/**< Number of Columns */
	unsigned short nLin;	/**< Number of Lines */
	unsigned char comp;		/**< Compression Method */
	}HritImgStruct;

/**
	#2 Image Navigation 
******************************/
typedef struct
	{
	unsigned char hdrType;	/**< Header Type */
	unsigned short recLen;	/**< Header Record Length */
	char projName[33];		/**< Projection Name */
	long cfac;				/**< Column Scaling Factor */
	long lfac;				/**< Line Scaling Factor */
	long coff;				/**< Column Offfset */
	long loff;				/**< Line Offset */
	}HritNav;

/**
	#3 Image Data Function
******************************/
typedef struct
	{
	unsigned char hdrType;	/**< Header Type */
	unsigned short recLen;	/**< Header Record Length */
	char *datDef;			/**< Data Definition Block */
	}HritDataFunc;

/**
	#4 Annotation 
******************************/
typedef struct
	{
	unsigned char hdrType;	/**< Header Type */
	unsigned short recLen;	/**< Header Record Length */
	char *annt;				/**< Annotation Text */
	}HritAnnt;

/**
	#5 Time Stamp
*******************************/
typedef struct
	{
	unsigned char hdrType;	/**< Header Type */
	unsigned short recLen;	/**< Header Record Length */
	unsigned char cdsP;		/**< CDS P Field */
	unsigned short cdsTD;	/**< CDS T Field (Counter of Days Starting from Jan 1, 1958) */
	unsigned long cdsTS;	/**< CDS T Field (Milliseconds of Day) */
	}HritTimeStamp;
	
/** not use
	#6 Ancillary Text
****************************
typedef struct
	{
	unsigned char hdrType;	**< Header Type *
	unsigned short recLen;	**< Header Record Length *
	char *ancText;			**< Ancillary Text *
	}HritAncillary;
*/

/* not use
	#7 Key Header
****************************
typedef struct
	{
	unsigned char hdrType;	**< Header Type *
	unsigned short recLen;	**< Header Record Length *
	unsigned long keyNo;
	}HritKey;
*/

/**
	#128 Image Segment Identification
****************************************/
typedef struct
	{
	unsigned char hdrType;		/**< Header Type */
	unsigned short recLen;		/**< Header Record Length */
	unsigned char segSeqNo;		/**< Image Segment Sequentional Number */
	unsigned char totalSegNo;	/**< Total Number of Image Segments */
	unsigned short segLineNo;	/**< Total Number of Line Image Segments */
	}HritImgSegmentId;
	
/** not use
	#129 Encryption Key Message Header
****************************************
typedef struct
	{
	unsigned char hdrType;	**< Header Type *
	unsigned short recLen;	**< Header Record Length *
	unsigned short stnNo;	**< Index of the User Station *
	}HritEncKeyMsg;
*/

/**
	# 130 Image Compensation Information Header
*********************************************/
typedef struct
	{
	unsigned char hdrType;	/**< Header Type */
	unsigned short recLen;	/**< Header Record Length */
	char *compInfo;			/**< Image Compensation Information */
	}HritImgCompInfo;

/**
	# 131 Image Observation Time Header
********************************************/
typedef struct
	{
	unsigned char hdrType;	/**< Header Type */
	unsigned short recLen;	/**< Header Record Length */
	char *obsTime;			/**< Image Observation Time */
	}HritImgObsTime;

/**
	# 132 Image Quality Information Header
********************************************/
typedef struct
	{
	unsigned char hdrType;	/**< Header Type */
	unsigned short recLen;	/**< Header Record Length */
	char *qInfo;			/**< Image Quality Information */
	}HritQualityInfo;

/**
	Calibration Table
********************************************/
typedef struct
	{
	int level;
	float phys;
	}HritCalTable;

/**
	HRIT Definition
*******************************************/
typedef struct
	{
	/* HRIT Header */
	HritPrimary		*prim;
	HritImgStruct		*str;
	HritNav			*nav;
	HritDataFunc		*datfunc;
	HritAnnt			*annt;
	HritTimeStamp		*stamp;
	HritImgSegmentId	*seg;
	HritImgCompInfo	*compinfo;
	HritImgObsTime	*obstime;
	HritQualityInfo	*qual;
	}HritHeader;

int make_hrit_header(HisdHeader *hisd, HritHeader *hrit, 
	double *radiance_table);
int make_hrit_data(HisdHeader *header,HritHeader *info,
    unsigned short *hisd_data,unsigned short *hrit_data,double *radiance_table);
int write_hrit_header(HritHeader *info, FILE *fp, const char byteOrder_flag);
int write_data(unsigned short *data, const int num, FILE *fp,
    const char byteOrder_flag);

