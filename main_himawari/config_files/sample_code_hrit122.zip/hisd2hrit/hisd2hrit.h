# define  NORMAL_END        0
# define  ERROR_ARG         1
# define  ERROR_FILE_OPEN   2
# define  ERROR_CALLOCATE   3
# define  ERROR_READ_HEADER 4
# define  ERROR_INFO        5
# define  ERROR_READ_DATA   6
# define  ERROR_PARAMETER   7
# define  ERROR_MAKE_HEADER 8
# define  ERROR_MAKE_DATA   9
# define  ERROR_WRITE       10

# define  MIN_ALBEDO    -0.001
# define  MAX_ALBEDO    1.0
# define  B07_MAX_TBB   320.0
# define  B08_MAX_TBB   300.0
# define  B13_MAX_TBB   330.0
# define  B15_MAX_TBB   330.0
# define  Bxx_MAX_TBB   330.0
# define  B07_MIN_TBB   130.0
# define  B08_MIN_TBB   130.0
# define  B13_MIN_TBB   130.0
# define  B15_MIN_TBB   130.0
# define  Bxx_MIN_TBB   130.0

# define  DELT        1.5
# define  DELT_N      30

/* May, 2015    Changed the default "byte order"
# define  ENDIAN 0      // 1: little endian  0: big endian
*/
# define  ENDIAN 1      // 0: little endian  1: big endian
# define  BITNUM 10

void mjd_to_date(double mjd, int date[7]);
void DateGetNowInts(int  date[7] );
double DateIntsToMjd(const int date[7] );
