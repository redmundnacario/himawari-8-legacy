/* ----------------------------------------------------------------------------
    Sample source code for Himawari Satandard Data

    Copyright (C) 2015 MSC (Meteorological Satellite Center) of JMA

    Disclaimer  :
        MSC does not guarantee regarding the correctness, accuracy, reliability,
        or any other aspect regarding use of these sample codes.

    Detail of Himawari Standard Format :
        For data structure of Himawari Standard Format, prelese refer to MSC
        Website and Himawari Standard Data User's Guid.

        MSC Website
        http://www.jma-net.go.jp/msc/en/

        Himawari Standard Data User's Guid
        http://www.data.jma.go.jp/mscweb/en/himawari89/space_segment/hsd_sample/HS_D_users_guide_en.pdf

    History
        March,   2015  First release
        May,     2015  Fixed bug in funcntion copy_str() 
                       Changed the defult "ENDIAN" value
        September,2015 Fixed bug in function make_calib_table()
        October, 2015  Fixed bug in function make_compesation_table()
                       For converting HISD of band 3 to HRIT data
                       Fixed bug in function make_hrit_header()
                       For converting HISD of regional observation to HRIT data
---------------------------------------------------------------------------- */
# include <stdio.h>
# include <string.h>
# include <stdlib.h>
# include <time.h>
# include <math.h>

# include "hisd.h"
# include "hrit.h"
# include "hisd2hrit.h"

static void copy_str(int *kk,char *header_text,char *table);
static int make_obstime_table(HisdHeader *header,HritHeader *info);
static int make_error_table(HisdHeader *header,HritHeader *info);
static int make_compesation_table(HisdHeader *header, HritHeader *info);
static int make_calib_table(HisdHeader *header,HritHeader *info, 
    double *radiance_table);
static int make_hrit_annt(HisdHeader *hisd, char *output_filename);

/* ---------------------------------------------------------------------------
  make_hrit_header()
 -----------------------------------------------------------------------------*/
int make_hrit_header(HisdHeader *header, HritHeader *info, 
    double *radiance_table){
    int iDate[7];
    double fileCreationMjd;

    // 1 allocate
    info->prim    =(HritPrimary *)     calloc(1,sizeof(HritPrimary)     );
    info->str     =(HritImgStruct *)   calloc(1,sizeof(HritImgStruct)   );
    info->nav     =(HritNav *)         calloc(1,sizeof(HritNav)         );
    info->datfunc =(HritDataFunc *)    calloc(1,sizeof(HritDataFunc)    );
    info->annt    =(HritAnnt *)        calloc(1,sizeof(HritAnnt)        );
    info->stamp   =(HritTimeStamp *)   calloc(1,sizeof(HritTimeStamp)   );
    info->seg     =(HritImgSegmentId *)calloc(1,sizeof(HritImgSegmentId));
    info->compinfo=(HritImgCompInfo *) calloc(1,sizeof(HritImgCompInfo) );
    info->obstime =(HritImgObsTime *)  calloc(1,sizeof(HritImgObsTime)  );
    info->qual    =(HritQualityInfo *) calloc(1,sizeof(HritQualityInfo) );
    if( info->prim    == NULL || info->str      == NULL ||
        info->nav     == NULL || info->datfunc  == NULL ||
        info->annt    == NULL || info->stamp    == NULL ||
        info->seg     == NULL || info->compinfo == NULL ||
        info->obstime == NULL || info->qual     == NULL ){
        fprintf(stderr,"allocate error\n");
        return(ERROR_CALLOCATE);
    }
    // 2 header block
    /* #0 -------------------------------*/
    info->prim->hdrType   = 0;  // fixed
    info->prim->recLen    = 16; // fixed
    info->prim->typeCode  = 0;  // fixed
    info->prim->hdrLen    = 0;  //<<==== later
    info->prim->datLen[0] = 0;  //<<==== later
    info->prim->datLen[1] = 0;  //<<==== later
    /* #1 -------------------------------*/
    info->str->hdrType = 1;     // fixed
    info->str->recLen  = 9;     // fixed
    info->str->bitPix  = 16;    // fixed
    info->str->nPix    = header->data->nPix;
    info->str->nLin    = header->data->nLin;
    info->str->comp    = 0;        // no compression
    /* #0 -------------------------------*/
    info->prim->fDatLen= info->str->nPix * info->str->nLin * 2. * 8. ;
    info->prim->datLen[0] = (info->prim->fDatLen / pow(2,32));
    info->prim->datLen[1] = fmod(info->prim->fDatLen , pow(2,32));
    /* #2 -------------------------------*/
    info->nav->hdrType  = 2;    // fixed
    info->nav->recLen   = 51;   // fixed
    sprintf(info->nav->projName,"GEOS(%6.2f)                    ",
        header->proj->subLon);
    info->nav->cfac     = header->proj->cfac;
    info->nav->lfac     = header->proj->lfac;
//  info->nav->coff     = info->str->nPix / 2.0 ;
//  info->nav->loff     = info->nav->coff;
//  HRIT Header Type #2 - COFF,LOFF :: = integer (4 byte)
    info->nav->coff     = (int)(header->proj->coff); // 2015.10
    info->nav->loff     = (int)(header->proj->loff); // 2015.10
    /* #3 -------------------------------*/
    info->datfunc->hdrType = 3; // fixed
    make_calib_table(header,info,radiance_table);
    /* #4 -------------------------------*/
    info->annt->hdrType = 4;    // fixed
    info->annt->annt=(char *)calloc(67,sizeof(char));
    make_hrit_annt(header,info->annt->annt);
    info->annt->recLen  = strlen(info->annt->annt) + 3;
    /* #5 -------------------------------*/
    info->stamp->hdrType = 5;   //fixed
    info->stamp->recLen  = 10;  //fixed
    info->stamp->cdsP    = 64;  //fixed
    DateGetNowInts(iDate);
    fileCreationMjd = DateIntsToMjd(iDate);
    iDate[0] = 1958; iDate[1] = 1; iDate[2] = 1;
    iDate[3] = 0;    iDate[4] = 0; iDate[5] = 0; iDate[6] = 0;
    info->stamp->cdsTD = floor(fileCreationMjd) - DateIntsToMjd(iDate);
    info->stamp->cdsTS = (fmod(fileCreationMjd ,1.0) * 24 * 60 * 60 *1000);
    /* #128 -------------------------------*/
    info->seg->hdrType    = 128;        // fixed
    info->seg->recLen     = 7;          // fixed
    info->seg->segSeqNo   = header->seg->segSeqNo;
    info->seg->totalSegNo = header->seg->totalSegNum;
    if(info->seg->totalSegNo==1){
        info->seg->segSeqNo   = 0;
    }
    info->seg->segLineNo  = header->seg->strLineNo;
    /* #130 -------------------------------*/
    info->compinfo->hdrType = 130;
    make_compesation_table(header,info);
    /* #131 -------------------------------*/
    info->obstime->hdrType =131;
    make_obstime_table(header,info);
    /* #132 -------------------------------*/
    info->qual->hdrType =132;
    make_error_table(header,info);
    /* #0 -------------------------------*/
    info->prim->hdrLen    =         //
        info->prim->recLen  +        // 0
        info->str->recLen   +        // 1
        info->nav->recLen   +        // 2
        info->datfunc->recLen   +    // 3
        info->annt->recLen  +        // 4
        info->stamp->recLen +        // 5
        info->seg->recLen   +        // 128
        info->compinfo->recLen  +    // 130
        info->obstime->recLen   +    // 131
        info->qual->recLen ;        // 132
    /* ---------------------------------- */
    return(NORMAL_END);
}
/* -------------------------------------------------------------------------- 
 *     make_hrit_data()
   -------------------------------------------------------------------------- */
int make_hrit_data(HisdHeader *header,HritHeader *info,
    unsigned short *hisd_data,unsigned short *hrit_data,double *radiance_table){

    double    radiance;
    double    hrit_gain,hrit_cnst;
    int        level_num;
    int        ii,jj,kk;
    int        OUT_ERROR;
    int        hrit_count;
    // 1
    level_num = (int)pow(2,BITNUM);
    hrit_gain = (radiance_table[level_num-1] - radiance_table[0]) / 
                (double)(level_num -1);
    hrit_cnst = radiance_table[0];
    // 2 error pixels or outside scan area
    if( (header->calib->bandNo>=7 &&
        strstr(header->basic->satName,"Himawari")!=NULL ) ){
        OUT_ERROR = level_num -1;    // infra-red
    }else{
        OUT_ERROR = 0;        // visivle
    }
    // 3 count value
    for(jj=0;jj<header->data->nLin;jj++){
    for(ii=0;ii<header->data->nPix;ii++){
        kk=ii+jj*header->data->nPix;
        // outside scan area
        if(hisd_data[kk] == header->calib->outCount){
            hrit_data[kk] = OUT_ERROR;
        // error pixels
        }else if(hisd_data[kk] == header->calib->errorCount){
            hrit_data[kk] = OUT_ERROR;
        }else{
            radiance = hisd_data[kk] * header->calib->gain_cnt2rad +
                header->calib->cnst_cnt2rad;
            hrit_count = (int)((radiance - hrit_cnst) / hrit_gain + 0.5);
            // check count value
            if(hrit_count < 0)          {hrit_count=   0;}
            if(hrit_count >level_num -1){hrit_count= level_num-1;}
            //
            hrit_data[kk] = hrit_count;
        }
    }
    }
    return(NORMAL_END);
}
/* ---------------------------------------------------------------------------
  write_hrit_header()
 -----------------------------------------------------------------------------*/
int write_hrit_header(HritHeader *info, FILE *fp, char byteOrder_flag){
    char    byteSwap=0;    // 1 : swap   0 : not swap
    // 1 check byte order
    if(byteOrder() == byteOrder_flag){
        byteSwap = 0;
    }else{
        byteSwap = 1;
    }
    // 2 byte swap
    unsigned short prim_recLen     = info->prim->recLen;
    unsigned long  prim_hdrLen     = info->prim->hdrLen;
    unsigned long  prim_datLen0    = info->prim->datLen[0];
    unsigned long  prim_datLen1    = info->prim->datLen[1];
    unsigned short str_recLen      = info->str->recLen;
    unsigned short str_nPix        = info->str->nPix;
    unsigned short str_nLin        = info->str->nLin;
    unsigned short nav_recLen      = info->nav->recLen;
    unsigned long  nav_cfac        = info->nav->cfac;
    unsigned long  nav_lfac        = info->nav->lfac;
    unsigned long  nav_coff        = info->nav->coff;
    unsigned long  nav_loff        = info->nav->loff;
    unsigned short datfunc_rcLen   = info->datfunc->recLen;
    unsigned short annt_recLen     = info->annt->recLen;
    unsigned short stamp_recLen    = info->stamp->recLen;
    unsigned short stamp_cdsTD     = info->stamp->cdsTD;
    unsigned long  stamp_cdsTS     = info->stamp->cdsTS;
    unsigned short seg_recLen      = info->seg->recLen;
    unsigned short seg_segLineNo   = info->seg->segLineNo;
    unsigned short compinfo_recLen = info->compinfo->recLen;
    unsigned short obstime_recLen  = info->obstime->recLen;
    unsigned short qual_recLen     = info->qual->recLen;
    if(byteSwap == 1){
        swapBytes(&prim_recLen,2,1);
        swapBytes(&prim_hdrLen,4,1);
        swapBytes(&prim_datLen0,4,1);
        swapBytes(&prim_datLen1,4,1);
        swapBytes(&str_recLen,2,1);
        swapBytes(&str_nPix,2,1);
        swapBytes(&str_nLin,2,1);
        swapBytes(&nav_recLen,2,1);
        swapBytes(&nav_cfac,4,1);
        swapBytes(&nav_lfac,4,1);
        swapBytes(&nav_coff,4,1);
        swapBytes(&nav_loff,4,1);
        swapBytes(&datfunc_rcLen,2,1);
        swapBytes(&annt_recLen,2,1);
        swapBytes(&stamp_recLen,2,1);
        swapBytes(&stamp_cdsTD,2,1);
        swapBytes(&stamp_cdsTS,4,1);
        swapBytes(&seg_recLen,2,1);
        swapBytes(&seg_segLineNo,2,1);
        swapBytes(&compinfo_recLen,2,1);
        swapBytes(&obstime_recLen,2,1);
        swapBytes(&qual_recLen,2,1);
    }
    // 3 write
    /* #0 -------------------------------------*/
    if( (1>fwrite(&info->prim->hdrType, 1,1,fp) ) ||
        (1>fwrite(&prim_recLen,         2,1,fp) ) ||
        (1>fwrite(&info->prim->typeCode,1,1,fp) ) ||
        (1>fwrite(&prim_hdrLen,         4,1,fp) ) ||
        (1>fwrite(&prim_datLen0,        4,1,fp) ) ||
        (1>fwrite(&prim_datLen1,        4,1,fp) )){
        fprintf(stderr,"header #0 write error\n");
        return(ERROR_WRITE);
    }
    /* #1 -------------------------------------*/
    if( (1>fwrite(&info->str->hdrType,1,1,fp) ) ||
        (1>fwrite(&str_recLen,        2,1,fp) ) ||
        (1>fwrite(&info->str->bitPix, 1,1,fp) ) ||
        (1>fwrite(&str_nPix,          2,1,fp) ) ||
        (1>fwrite(&str_nLin,          2,1,fp) ) ||
        (1>fwrite(&info->str->comp,   1,1,fp) )){
        fprintf(stderr,"header #1 write error\n");
        return(ERROR_WRITE);
    }
    /* #2 -------------------------------------*/
    if( (1>fwrite(&info->nav->hdrType, 1,1,fp) ) ||
        (1>fwrite(&nav_recLen,         2,1,fp) ) ||
        (1>fwrite(&info->nav->projName,1,32,fp)) ||
        (1>fwrite(&nav_cfac,           4,1,fp) ) ||
        (1>fwrite(&nav_lfac,           4,1,fp) ) ||
        (1>fwrite(&nav_coff,           4,1,fp) ) ||
        (1>fwrite(&nav_loff,           4,1,fp) )){
        fprintf(stderr,"header #2 write error\n");
        return(ERROR_WRITE);
    }
    /* #3 -------------------------------------*/
    if( (1>fwrite(&info->datfunc->hdrType,1,1,fp) ) ||
        (1>fwrite(&datfunc_rcLen,         2,1,fp) ) ||
        (1>fwrite(&info->datfunc->datDef[0],(info->datfunc->recLen-3),1,fp))){
        fprintf(stderr,"header #3 write error\n");
        return(ERROR_WRITE);
    }
    /* #4 -------------------------------------*/
    if( (1>fwrite(&info->annt->hdrType,1,1,fp) ) ||
        (1>fwrite(&annt_recLen,        2,1,fp) ) ||
        (1>fwrite(&info->annt->annt[0],(info->annt->recLen-3),1,fp) )){
        fprintf(stderr,"header #4 write error\n");
        return(ERROR_WRITE);
    }
    /* #5 -------------------------------------*/
    if( (1>fwrite(&info->stamp->hdrType,1,1,fp) ) ||
        (1>fwrite(&stamp_recLen,        2,1,fp) ) ||
        (1>fwrite(&info->stamp->cdsP,   1,1,fp) ) ||
        (1>fwrite(&stamp_cdsTD,         2,1,fp) ) ||
        (1>fwrite(&stamp_cdsTS,         4,1,fp) )){
        fprintf(stderr,"header #5 write error\n");
        return(ERROR_WRITE);
    }
    /* #128 -----------------------------------*/
    if( (1>fwrite(&info->seg->hdrType,   1,1,fp) ) ||
        (1>fwrite(&seg_recLen,           2,1,fp) ) ||
        (1>fwrite(&info->seg->segSeqNo,  1,1,fp) ) ||
        (1>fwrite(&info->seg->totalSegNo,1,1,fp) ) ||
        (1>fwrite(&seg_segLineNo,        2,1,fp) )){
        fprintf(stderr,"header #128 write error\n");
        return(ERROR_WRITE);
    }
    /* #130 -----------------------------------*/
    if( (1>fwrite(&info->compinfo->hdrType, 1,1,fp) ) ||
        (1>fwrite(&compinfo_recLen,         2,1,fp) ) ||
        (1>fwrite(&info->compinfo->compInfo[0],
            (info->compinfo->recLen-3),1,fp) )){
        fprintf(stderr,"header #130 write error\n");
        return(ERROR_WRITE);
    }
    /* #131 -----------------------------------*/
    if( (1>fwrite(&info->obstime->hdrType,1,1,fp) ) ||
        (1>fwrite(&obstime_recLen,        2,1,fp) ) ||
        (1>fwrite(&info->obstime->obsTime[0],(info->obstime->recLen-3),1,fp))){
        fprintf(stderr,"header #131 write error\n");
        return(ERROR_WRITE);
    }
    /* #132 -----------------------------------*/
    if( (1>fwrite(&info->qual->hdrType,1,1,fp) ) ||
        (1>fwrite(&qual_recLen,        2,1,fp) ) ||
        (1>fwrite(&info->qual->qInfo[0],(info->qual->recLen-3),1,fp) )){
        fprintf(stderr,"header #132 write error\n");
        return(ERROR_WRITE);
    }
    return(NORMAL_END);
}
/* ---------------------------------------------------------------------------
  write_data()
 -----------------------------------------------------------------------------*/
int write_data(unsigned short *data, const int num, FILE *fp, 
    const char byteOrder_flag){
    char byteSwap=0;
    // 1 check byte order
    if(byteOrder() == byteOrder_flag ){
        byteSwap=0;
    }else{
        byteSwap=1;
    }
    // 2 byte swap
    if(byteSwap == 1){
        swapBytes(&data[0],2,num);
    }
    // 3 write data block
    if( num > fwrite(data,sizeof(unsigned short),num,fp)){
        fprintf(stderr,"data write error\n");
        return(ERROR_WRITE);
    }
    //
    return(NORMAL_END);
}

/* -------------------------------------------------------------------------- 
 *     copy_str()
   -------------------------------------------------------------------------- */
/*  May, 2015  Bug fixed 
static void copy_str(int *kk,HritHeader *info,char *table){
    memcpy(&info->datfunc->datDef[*kk],table,strlen(table));
    *kk = *kk + strlen(table);
    info->datfunc->datDef[*kk] = 0xd ;    // <CR>
    *kk = *kk +1 ;
}
*/
static void copy_str(int *kk,char *header_text  ,char *table){
    memcpy(&header_text[*kk],table,strlen(table));
    *kk = *kk + strlen(table);
    header_text[*kk] = 0xd ;  // <CR>
    *kk = *kk +1 ;
}

/* -------------------------------------------------------------------------- 
 *     make_obstime_table()
   -------------------------------------------------------------------------- */
static int make_obstime_table(HisdHeader *header,HritHeader *info){
    int ii,kk;
    char table[20];
    kk=0;

    info->obstime->obsTime=(char *)calloc
        (31 * header->obstime->obsNum,sizeof(char));
    if(info->obstime->obsTime==NULL){
        fprintf(stderr,"allocate error\n");
        return(ERROR_CALLOCATE);
    }
    for(ii=0;ii<header->obstime->obsNum;ii++){
        sprintf(table,"LINE:=%d",header->obstime->lineNo[ii]);
        copy_str(&kk,info->obstime->obsTime,table);        // 2015.05
        sprintf(table,"TIME:=%12.6f",header->obstime->obsMJD[ii]);
        copy_str(&kk,info->obstime->obsTime,table);        // 2015.05
    }
    info->obstime->recLen = kk + 3;
    return(NORMAL_END);
}
/* -------------------------------------------------------------------------- 
 *     make_error_table()
   -------------------------------------------------------------------------- */
static int make_error_table(HisdHeader *header,HritHeader *info){
    int ii,kk;
    char table[20];
    kk=0;
    if(header->error->errorNum >0){
        info->qual->qInfo =(char *)calloc
            (26 * header->error->errorNum,sizeof(char));
        if(info->qual->qInfo==NULL){
            fprintf(stderr,"allocate error\n");
            return(ERROR_CALLOCATE);
        }
        for(ii=0;ii<header->error->errorNum;ii++){
            sprintf(table,"LINE:=%d",    header->error->lineNo[ii]);
            copy_str(&kk,info->qual->qInfo,table);        // 2015.05
            sprintf(table,"ERROR:=%6.4f", 
                (double)header->error->errPixNum[ii] / header->data->nPix );
            copy_str(&kk,info->qual->qInfo,table);        // 2015.05
        }
    }else{
        info->qual->qInfo =(char *)calloc (10,sizeof(char));
        if(info->qual->qInfo==NULL){
            fprintf(stderr,"allocate error\n");
            return(ERROR_CALLOCATE);
        }
        sprintf(table,"NO_ERROR");
        copy_str(&kk,info->qual->qInfo,table);        // 2015.05
    }
    info->qual->recLen = kk + 3;

    return(NORMAL_END);
}

/* -------------------------------------------------------------------------- 
 *     make_compesation_table()
   -------------------------------------------------------------------------- */
static int make_compesation_table(HisdHeader *header, HritHeader *info){
    int    ii,kk;
    char table[20];
    double columnShift,lineShift;
    
    // 1 calloc
//    info->compinfo->compInfo=(char *)calloc
//        (38 * header->navcorr->correctNum,sizeof(char));
    info->compinfo->compInfo=(char *)calloc                    // 2015.10
        (50 * header->navcorr->correctNum,sizeof(char));    // 2015.10
    if(info->compinfo->compInfo==NULL){
        fprintf(stderr,"allocate error\n");
        return(ERROR_CALLOCATE);
    }
    //
    kk = 0;
    for(ii=0;ii<header->navcorr->correctNum;ii++){
        sprintf(table,"LINE:=%d",header->navcorr->lineNo[ii]);
        copy_str(&kk,info->compinfo->compInfo,table);    // 2015.05
        columnShift = header->data->nPix / 2.0 +
                        header->navcorr->columnShift[ii];
        lineShift   = header->data->nPix / 2.0 +
                        header->navcorr->columnShift[ii];
        sprintf(table,"COFF:=%6.1f",columnShift);
        copy_str(&kk,info->compinfo->compInfo,table);    // 2015.05
        sprintf(table,"LOFF:=%6.1f",lineShift);
        copy_str(&kk,info->compinfo->compInfo,table);    // 2015.05
    }
    info->compinfo->recLen = kk + 3;

    return (NORMAL_END);
}
/* -------------------------------------------------------------------------- 
 *     make_calib_table()
   -------------------------------------------------------------------------- */
static int make_calib_table(HisdHeader *header,HritHeader *info, 
    double *radiance_table){
    int        ii,kk;
    char    table[20];
    double  phy[2];
    double  rad[2];
    int        level_num;
    double temperature0;
    int ii0;

    info->datfunc->datDef = (char *)calloc(pow(2,BITNUM) * 14,sizeof(char));
    level_num = (int)pow(2,BITNUM);

    // 1 common part
    kk=0;
    sprintf(table,"$HALFTONE:=16");
    copy_str(&kk,info->datfunc->datDef,table);    // 2015.05
    // 2 visible band
    if(    header->calib->bandNo < 7 &&
        strstr(header->basic->satName,"Himawari")!=NULL ){
        // 2-1 raidance_table
        phy[0] = MIN_ALBEDO;
        phy[1] = MAX_ALBEDO;
        rad[0] = phy[0] / header->calib->rad2albedo;
        rad[1] = phy[1] / header->calib->rad2albedo;
        for(ii=0;ii<level_num;ii++){
            radiance_table[ii] = ((rad[1] - rad[0]) / (float)(level_num-1)) *
                                 ii + rad[0];
        }
        // 2-2 _NAME:=VISIBLE
        sprintf(table,"_NAME:=VISIBLE");
        copy_str(&kk,info->datfunc->datDef,table);    // 2015.05
        // 2-3 _UNIT:=ALBEDO(%)
        sprintf(table,"_UNIT:=ALBEDO(%%)");
        copy_str(&kk,info->datfunc->datDef,table);    // 2015.05
        // 2-4 0:=-0.10
        sprintf(table,"0:=%5.2f",MIN_ALBEDO*100.0);
        copy_str(&kk,info->datfunc->datDef,table);    // 2015.05
        // 2-5 1023:=100.00
        sprintf(table,"%d:=%5.2f",level_num-1,MAX_ALBEDO*100.0);
        copy_str(&kk,info->datfunc->datDef,table);    // 2015.05
        // 2-6 65535:=100.00
        sprintf(table,"65535:=%5.2f",MAX_ALBEDO*100.0);
        copy_str(&kk,info->datfunc->datDef,table);    // 2015.05
    // 3 infra-red band
    }else if(header->calib->bandNo >=7 &&
            strstr(header->basic->satName,"Himawari")!=NULL ){
        // 3-1 raidance_table
        double    lambda,planck_c1,planck_c2;
        double    C0,C1,C2,D0,D1,D2;
        double    effective_temp,temperature;
        lambda = header->calib->waveLen / 1000000.0;
        planck_c1=  2.0 * header->calib->planckConst *
                    pow(header->calib->lightSpeed,2.0) /
                    pow(lambda,5.0) / 1000000.0 ;
        planck_c2=  header->calib->planckConst * header->calib->lightSpeed /
                    header->calib->bolzConst / lambda ;
        switch (header->calib->bandNo){
            case  7:
                phy[0] = B07_MAX_TBB; phy[1] = B07_MIN_TBB; break;
            case  8:
                phy[0] = B08_MAX_TBB; phy[1] = B08_MIN_TBB; break;
            case 13:
                phy[0] = B13_MAX_TBB; phy[1] = B13_MIN_TBB; break;
            case 15:
                phy[0] = B15_MAX_TBB; phy[1] = B15_MIN_TBB; break;
            default:
                phy[0] = Bxx_MAX_TBB; phy[1] = Bxx_MIN_TBB; break;
        }
        C0 = header->calib->btp2rad_c0;
        C1 = header->calib->btp2rad_c1;
        C2 = header->calib->btp2rad_c2;
        D0 = header->calib->rad2btp_c0;
        D1 = header->calib->rad2btp_c1;
        D2 = header->calib->rad2btp_c2;
        for(ii=0;ii<2;ii++){
            effective_temp = C0 + (C1 * phy[ii]) + (C2 * phy[ii] * phy[ii]);
            rad[ii] = planck_c1 / ( exp(planck_c2/effective_temp)-1.0);
        }
        for(ii=0;ii<level_num;ii++){
            radiance_table[ii] = ((rad[1] - rad[0]) / (float)(level_num-1)) *
                                 ii + rad[0];
        }
        // 3-2-1 _NAME:=INFRARED                    // 2015.09
        sprintf(table,"_NAME:=INFRARED");            // 2015.09
        copy_str(&kk,info->datfunc->datDef,table);    // 2015.09
        // 3-2-2
        sprintf(table,"_UNIT:=KELVIN");
        copy_str(&kk,info->datfunc->datDef,table);    // 2015.05
        // 3-3
        temperature0 = 500.0;
        ii0 = -100;
        for(ii=0;ii<level_num;ii++){
            effective_temp = planck_c2 /  
                log( ( planck_c1 / radiance_table[ii] ) + 1.0);
            temperature = D0 + ( D1 * effective_temp) + 
                (D2 * effective_temp * effective_temp);
            if(temperature0 - temperature > DELT || ii - ii0 >= DELT_N){
                temperature0 = temperature;
                ii0 = ii;
                sprintf(table,"%d:=%6.2f",ii,temperature);
                copy_str(&kk,info->datfunc->datDef,table);    // 2015.05
            }
        }
        // 3-4
        ii=65535;
        sprintf(table,"%d:=%6.2f",ii,temperature);
        copy_str(&kk,info->datfunc->datDef,table);    // 2015.05
    }else{
        fprintf(stderr,"make_calib_table()\n");
        return(ERROR_PARAMETER);
    }
    info->datfunc->recLen = kk + 3;
    return(NORMAL_END);
}

/* ---------------------------------------------------------------------------
  make_hrit_annt()
 -----------------------------------------------------------------------------*/
static int make_hrit_annt(HisdHeader *header, char *output_filename){
    char CH[4];
    int  date[7];
    // 1 ch
    // Himawari-8,9
    if(strstr(header->basic->satName,"Himawari") != NULL){
        switch(header->calib->bandNo){
            case  3: strcpy(CH,"VIS"); break;
            case  7: strcpy(CH,"IR4"); break;
            case  8: strcpy(CH,"IR3"); break;
            case 13: strcpy(CH,"IR1"); break;
            case 15: strcpy(CH,"IR2"); break;
            //
            default :
                sprintf(CH,"B%02d",header->calib->bandNo); break;
        }
    }else{
        fprintf(stderr,"make_hrit_annt() : error\n");
        return(ERROR_PARAMETER);
    }
    // 2 date
    mjd_to_date(header->basic->ObsStartTime,date);
    // 3 output file name
    sprintf(output_filename,"IMG_DK01%3s_%04d%02d%02d%02d%02d_%03d",
        CH, date[0], date[1], date[2], date[3], date[4],
        header->seg->segSeqNo );
    //
    return(NORMAL_END);
}

