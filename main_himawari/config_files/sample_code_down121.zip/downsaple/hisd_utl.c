/* ----------------------------------------------------------------------------
	Sample source code for Himawari Satandard Data

	Copyright (C) 2015 MSC (Meteorological Satellite Center) of JMA

	Disclaimer:
		MSC does not guarantee regarding the correctness, accuracy, reliability,
		or any other aspect regarding use of these sample codes.

	Detail of Himawari Standard Format:
		For data structure of Himawari Standard Format, prelese refer to MSC
		Website and Himawari Standard Data User's Guide.

		MSC Website
		http://www.jma-net.go.jp/msc/en/

		Himawari Standard Data User's Guide
		http://www.data.jma.go.jp/mscweb/en/himawari89/space_segment/hsd_sample/HS_D_users_guide_en.pdf

	History
		March,   2015  First release
		May,     2015  Change for version 1.2
                       (write_hisd_header() , hisd_swap_header())
---------------------------------------------------------------------------- */
# include <stdio.h>
# include <string.h>
# include <stdlib.h>
# include <time.h>
# include <math.h>

# include "hisd.h"
# include "downsample.h"
# include "date_utl.h"

/* --------------------------------------------------------------------------
 *	make_hisd_header()
 --------------------------------------------------------------------------*/
int make_hisd_header(HisdHeader *head_o, HisdHeader *head_d){

	int iDate[7];
	// 1 allocate
	head_d->basic      = (Basic_Info      *)calloc(1,sizeof(Basic_Info));
	head_d->data       = (Data_Info       *)calloc(1,sizeof(Data_Info));
	head_d->proj       = (Proj_Info       *)calloc(1,sizeof(Proj_Info));
	head_d->nav        = (Navi_Info       *)calloc(1,sizeof(Navi_Info));
	head_d->calib      = (Calib_Info      *)calloc(1,sizeof(Calib_Info));
	head_d->interCalib = (InterCalib_Info *)calloc(1,sizeof(InterCalib_Info));
	head_d->seg        = (Segm_Info       *)calloc(1,sizeof(Segm_Info));
	head_d->navcorr    = (NaviCorr_Info   *)calloc(1,sizeof(NaviCorr_Info));
	head_d->obstime    = (ObsTime_Info    *)calloc(1,sizeof(ObsTime_Info));
	head_d->error      = (Error_Info      *)calloc(1,sizeof(Error_Info));
	head_d->spare      = (Spare           *)calloc(1,sizeof(Spare));
	head_d->correct_table = (Correct_Table *)calloc(1,sizeof(Correct_Table));
	if( head_d->basic  == NULL || head_d->data       == NULL ||
		head_d->proj   == NULL || head_d->nav        == NULL ||
		head_d->calib  == NULL || head_d->interCalib == NULL ||
		head_d->seg    == NULL || head_d->navcorr    == NULL ||
		head_d->obstime== NULL || head_d->error      == NULL ||
		head_d->spare  == NULL ){
		fprintf(stderr,"calloc error\n");
		return(ERROR_CALLOCATE);
	}
	// 2 copy header infomation
	memcpy(head_d->basic,     head_o->basic, sizeof(Basic_Info));
	memcpy(head_d->data,      head_o->data,  sizeof(Data_Info));
	memcpy(head_d->proj,      head_o->proj,  sizeof(Proj_Info));
	memcpy(head_d->nav,       head_o->nav,   sizeof(Navi_Info));
	memcpy(head_d->calib,     head_o->calib, sizeof(Calib_Info));
	memcpy(head_d->interCalib,head_o->interCalib,sizeof(InterCalib_Info));
	memcpy(head_d->seg,       head_o->seg,   sizeof(Segm_Info));
	memcpy(head_d->navcorr,   head_o->navcorr,   sizeof(NaviCorr_Info));
	memcpy(head_d->obstime,   head_o->obstime,   sizeof(ObsTime_Info));
	memcpy(head_d->error,     head_o->error, sizeof(Error_Info));
	memcpy(head_d->spare,     head_o->spare, sizeof(Spare));
	// #1
	head_d->basic->byteOrder = ENDIAN;   // 2015.06 add         // #1-4
	DateGetNowInts(iDate);
	head_d->basic->fileCreationMjd = DateIntsToMjd(iDate);		// #1-12
	head_d->basic->dataLen = head_o->basic->dataLen / 2 / 2;	// #1-14
	// file name
	// #2
	head_d->data->nPix = head_o->data->nPix / 2;				// #2-4
	head_d->data->nLin = head_o->data->nLin / 2;				// #2-5
	// #3
	switch (head_o->proj->cfac){
		case HISD_CFAC_05:	// 0.5 km to 1 km
			head_d->proj->cfac = HISD_CFAC_10;					// #3-4
			head_d->proj->lfac = HISD_CFAC_10;					// #3-5
			head_d->basic->fileName[31] = 49;	// 1
			head_d->basic->fileName[32] = 48;	// 0
			break;
		case HISD_CFAC_10: // 1 km to 2 km
			head_d->proj->cfac = HISD_CFAC_20;
			head_d->proj->lfac = HISD_CFAC_20;
			head_d->basic->fileName[31] = 50;	// 2
			head_d->basic->fileName[32] = 48;	// 0
			break;
		case HISD_CFAC_20:	// 2 km to 4 km
			head_d->proj->cfac = HISD_CFAC_40;
			head_d->proj->lfac = HISD_CFAC_40;
			head_d->basic->fileName[31] = 52;	// 4
			head_d->basic->fileName[32] = 48;	// 0
			break;
		case HISD_CFAC_40: // 4 km to 8 km      // 2015.06 added
			head_d->proj->cfac = HISD_CFAC_80;
			head_d->proj->lfac = HISD_CFAC_80;
			head_d->basic->fileName[31] = 56;	// 8
			head_d->basic->fileName[32] = 48;	// 0
			break;
		default:
			fprintf(stderr,"make_hisd_header()\n");
			return(ERROR_PARAMETER);
			break;
	}
	head_d->proj->coff = (head_o->proj->coff -0.5) / 2 + 0.5; // #3-6
	head_d->proj->loff = (head_o->proj->loff -0.5) / 2 + 0.5; // #3-7
	// #4	not change
	// #5	not change
	// #6	not change
	// #7
	head_d->seg->strLineNo = ( head_o->seg->strLineNo -1 )/ 2 +1;	// #7-5
	// #8
	head_d->navcorr->correctNum = head_o->navcorr->correctNum / 2 + 1;
	head_d->navcorr->lineNo = (unsigned short *)calloc
		(head_d->navcorr->correctNum,sizeof(unsigned short));
	head_d->navcorr->columnShift = (float *)calloc
		(head_d->navcorr->correctNum,sizeof(float));
	head_d->navcorr->lineShift = (float *)calloc
		(head_d->navcorr->correctNum,sizeof(float));
	if( head_d->navcorr->lineNo == NULL ||
		head_d->navcorr->columnShift == NULL ||
		head_d->navcorr->lineShift ==NULL ){
		fprintf(stderr,"calloc error\n");
		return(ERROR_CALLOCATE);
	}
	int ii,kk;
	kk=0;
	for(ii=0;ii<head_o->navcorr->correctNum;ii++){
		if( ( ii % 2 == 0) || ( ii == head_o->navcorr->correctNum-1 )){
			head_d->navcorr->lineNo[kk] =
				(head_o->navcorr->lineNo[ii] -1 ) / 2 +1;
			head_d->navcorr->columnShift[kk]=
				(head_o->navcorr->columnShift[ii] ) / 2.0;
			head_d->navcorr->lineShift[kk]=
				(head_o->navcorr->lineShift[ii] ) / 2.0;
			kk++;
		}
	}
	head_d->navcorr->correctNum = kk;
	head_d->navcorr->BlockLen = 61 + 10 * head_d->navcorr->correctNum;
	// #9
	kk=0;
	head_d->obstime->obsNum = head_o->obstime->obsNum / 2 +1;
	head_d->obstime->lineNo =(unsigned short *)calloc
		(head_d->obstime->obsNum,sizeof(unsigned short));
	head_d->obstime->obsMJD =(double *)calloc
		(head_d->obstime->obsNum,sizeof(double));
	if( head_d->obstime->lineNo == NULL ||
		head_d->obstime->obsMJD == NULL ){
		fprintf(stderr,"calloc error\n");
		return(ERROR_CALLOCATE);
	}
	for(ii=0;ii<head_o->obstime->obsNum;ii++){
		if( ( ii % 2 == 0) || ( ii == head_o->obstime->obsNum-1 ) ){
			head_d->obstime->lineNo[kk] =
				(head_o->obstime->lineNo[ii] -1) / 2 +1;
			head_d->obstime->obsMJD[kk] = head_o->obstime->obsMJD[ii];
			kk++;
		}
	}
	head_d->obstime->obsNum = kk;
	head_d->obstime->BlockLen= 45 + 10 * head_d->obstime->obsNum;
	// #10
	// (later)
	// #11 not change
	// #1
	head_d->basic->totalHeaderLen = 
		+ head_d->basic->BlockLen
		+ head_d->data->BlockLen
		+ head_d->proj->BlockLen
		+ head_d->nav->BlockLen
		+ head_d->calib->BlockLen
		+ head_d->interCalib->BlockLen
		+ head_d->seg->BlockLen
		+ head_d->navcorr->BlockLen
		+ head_d->obstime->BlockLen
		+ head_d->error->BlockLen
		+ head_d->spare->BlockLen;
	//
	return(NORMAL_END);
}

/* --------------------------------------------------------------------------
 *	make_hisd_data()
 --------------------------------------------------------------------------*/
int make_hisd_data(HisdHeader *head_o, HisdHeader *head_d,
    unsigned short *data_o, unsigned short *data_d){

	int i1,j1,k1,i2,j2,k2;
	int nLin2 = head_d->data->nLin;
	int nPix1 = head_o->data->nPix;
	int nPix2 = head_d->data->nPix;

	// Nearest Neighbor
	for(j2=0;j2<nLin2;j2++){
	for(i2=0;i2<nPix2;i2++){
		i1 = i2 * 2;
		j1 = j2 * 2;
		k1 = i1 + j1 * nPix1;
		k2 = i2 + j2 * nPix2;
		data_d[k2] = data_o[k1]; 
	}
	}
	return(NORMAL_END);
}

/* --------------------------------------------------------------------------
 *	make_hisd_errorinfo()
 --------------------------------------------------------------------------*/
int make_hisd_errorinfo(HisdHeader *head_d,unsigned short *data_d){
	int ii,jj,kk;
	int *errorNum;

	// 1 check error pixels
	head_d->error->errorNum = 0;
	errorNum = (int *)calloc(head_d->data->nLin,sizeof(int));
	for(jj=0;jj<head_d->data->nLin;jj++){
		errorNum[jj]=0;
		for(ii=0;ii<head_d->data->nPix;ii++){
			kk=ii + jj * head_d->data->nPix;
			if(data_d[kk] == head_d->calib->errorCount){
				errorNum[jj] ++ ;
			}
		}
		if(errorNum[jj] >= 1){
			head_d->error->errorNum ++;
		}
	}
	// 2 Error infomation block
	if(head_d->error->errorNum >=1){
		head_d->error->lineNo = (unsigned short *)calloc
			(head_d->error->errorNum,sizeof(unsigned short));
		head_d->error->errPixNum = (unsigned short *)calloc
			(head_d->error->errorNum,sizeof(unsigned short));
		if(head_d->error->lineNo == NULL || head_d->error->errPixNum == NULL){
			fprintf(stderr,"calloc error\n");
			return(ERROR_CALLOCATE);
		}
		kk=0;
		for(jj=0;jj<head_d->data->nLin;jj++){
			if(errorNum[jj] >= 1){
				head_d->error->lineNo[kk] = jj + head_d->seg->strLineNo;
				head_d->error->errPixNum[kk] = errorNum[jj];
				kk++;
			}
		}
	}
	// 3 BlockLen
	head_d->error->BlockLen = 47 + 4 * head_d->error->errorNum;
	head_d->basic->totalHeaderLen = 
		+ head_d->basic->BlockLen
		+ head_d->data->BlockLen
		+ head_d->proj->BlockLen
		+ head_d->nav->BlockLen
		+ head_d->calib->BlockLen
		+ head_d->interCalib->BlockLen
		+ head_d->seg->BlockLen
		+ head_d->navcorr->BlockLen
		+ head_d->obstime->BlockLen
		+ head_d->error->BlockLen
		+ head_d->spare->BlockLen;
	//
	free(errorNum);
	//
	return(NORMAL_END);
}

/* --------------------------------------------------------------------------
 *	write_hisd_header()
 --------------------------------------------------------------------------*/
int write_hisd_header(HisdHeader *header, FILE *fp, const char byteOrder_flag){
	unsigned short correctNum,obsNum,errorNum,bandNo;
	int		ii;
	char    byteSwap=0; // 1 : swap   0 : not swap
	float   version;

	// 1 check byte order
	if(byteOrder() == byteOrder_flag){
		byteSwap = 0;
	}else{
		byteSwap = 1;
	}
	// 2 byte swap
	correctNum = header->navcorr->correctNum;
	obsNum     = header->obstime->obsNum;
	errorNum   = header->error->errorNum;
	bandNo     = header->calib->bandNo;
	if(byteSwap==1){
		hisd_swap_header(header,correctNum,obsNum,errorNum,bandNo);
	}
	// 3 write
	/* #1 */
	if( (1>fwrite(&header->basic->HeaderNum,1,1,fp)) ||
		(1>fwrite(&header->basic->BlockLen,2,1,fp)) ||
		(1>fwrite(&header->basic->headerNum,2,1,fp)) ||
		(1>fwrite(&header->basic->byteOrder,1,1,fp)) ||
		(1>fwrite(&header->basic->satName,16,1,fp)) ||
		(1>fwrite(&header->basic->proName,16,1,fp)) ||
		(1>fwrite(&header->basic->ObsType1,4,1,fp)) ||
		(1>fwrite(&header->basic->ObsType2,2,1,fp)) ||
		(1>fwrite(&header->basic->TimeLine,2,1,fp)) ||
		(1>fwrite(&header->basic->ObsStartTime,8,1,fp)) ||
		(1>fwrite(&header->basic->ObsEndTime,8,1,fp)) ||
		(1>fwrite(&header->basic->fileCreationMjd,8,1,fp)) ||
		(1>fwrite(&header->basic->totalHeaderLen,4,1,fp)) ||
		(1>fwrite(&header->basic->dataLen,4,1,fp)) ||
		(1>fwrite(&header->basic->qflag1,1,1,fp)) ||
		(1>fwrite(&header->basic->qflag2,1,1,fp)) ||
		(1>fwrite(&header->basic->qflag3,1,1,fp)) ||
		(1>fwrite(&header->basic->qflag4,1,1,fp)) ||
		(1>fwrite(&header->basic->verName,32,1,fp)) ||
		(1>fwrite(&header->basic->fileName,128,1,fp)) ||
		(1>fwrite(&header->basic->spare,40,1,fp)) ){
		fprintf(stderr,"header #1 write error\n");
		return(ERROR_WRITE);
	}
	/* #2 */
	if( (1>fwrite(&header->data->HeaderNum,1,1,fp)) ||
		(1>fwrite(&header->data->BlockLen,2,1,fp)) ||
		(1>fwrite(&header->data->bitPix,2,1,fp)) ||
		(1>fwrite(&header->data->nPix,2,1,fp)) ||
		(1>fwrite(&header->data->nLin,2,1,fp)) ||
		(1>fwrite(&header->data->comp,1,1,fp)) ||
		(1>fwrite(&header->data->spare,40,1,fp)) ){
		fprintf(stderr,"header #2 write error\n");
		return(ERROR_WRITE);
	}
	/* #3 */
	if( (1>fwrite(&header->proj->HeaderNum,1,1,fp)) ||
		(1>fwrite(&header->proj->BlockLen,2,1,fp)) ||
		(1>fwrite(&header->proj->subLon,8,1,fp)) ||
		(1>fwrite(&header->proj->cfac,4,1,fp)) ||
		(1>fwrite(&header->proj->lfac,4,1,fp)) ||
		(1>fwrite(&header->proj->coff,4,1,fp)) ||
		(1>fwrite(&header->proj->loff,4,1,fp)) ||
		(1>fwrite(&header->proj->satDis,8,1,fp)) ||
		(1>fwrite(&header->proj->eqtrRadius,8,1,fp)) ||
		(1>fwrite(&header->proj->polrRadius,8,1,fp)) ||
		(1>fwrite(&header->proj->projParam1,8,1,fp)) ||
		(1>fwrite(&header->proj->projParam2,8,1,fp)) ||
		(1>fwrite(&header->proj->projParam3,8,1,fp)) ||
		(1>fwrite(&header->proj->projParamSd,8,1,fp)) ||
		(1>fwrite(&header->proj->resampleKind,2,1,fp)) ||
		(1>fwrite(&header->proj->resampleSize,2,1,fp)) ||
		(1>fwrite(&header->proj->spare,40,1,fp)) ){
		fprintf(stderr,"header #3 write error\n");
		return(ERROR_WRITE);
	}
	/* #4 */
	if( (1>fwrite(&header->nav->HeaderNum,1,1,fp)) ||
		(1>fwrite(&header->nav->BlockLen,2,1,fp)) ||
		(1>fwrite(&header->nav->navMjd,8,1,fp)) ||
		(1>fwrite(&header->nav->sspLon,8,1,fp)) ||
		(1>fwrite(&header->nav->sspLat,8,1,fp)) ||
		(1>fwrite(&header->nav->satDis,8,1,fp)) ||
		(1>fwrite(&header->nav->nadirLon,8,1,fp)) ||
		(1>fwrite(&header->nav->nadirLat,8,1,fp)) ||
		(1>fwrite(&header->nav->sunPos_x,8,1,fp)) ||
		(1>fwrite(&header->nav->sunPos_y,8,1,fp)) ||
		(1>fwrite(&header->nav->sunPos_z,8,1,fp)) ||
		(1>fwrite(&header->nav->moonPos_x,8,1,fp)) ||
		(1>fwrite(&header->nav->moonPos_y,8,1,fp)) ||
		(1>fwrite(&header->nav->moonPos_z,8,1,fp)) ||
		(1>fwrite(&header->nav->spare,40,1,fp)) ){
		fprintf(stderr,"header #4 write error\n");
		return(ERROR_WRITE);
	}
	/* #5 */
	if( (1>fwrite(&header->calib->HeaderNum,1,1,fp)) ||
		(1>fwrite(&header->calib->BlockLen,2,1,fp)) ||
		(1>fwrite(&header->calib->bandNo,2,1,fp)) ||
		(1>fwrite(&header->calib->waveLen,8,1,fp)) ||
		(1>fwrite(&header->calib->bitPix,2,1,fp)) ||
		(1>fwrite(&header->calib->errorCount,2,1,fp)) ||
		(1>fwrite(&header->calib->outCount,2,1,fp)) ||
		(1>fwrite(&header->calib->gain_cnt2rad,8,1,fp)) ||
		(1>fwrite(&header->calib->cnst_cnt2rad,8,1,fp)) ){
		fprintf(stderr,"header #5 write error\n");
		return(ERROR_WRITE);
	}
	if( (bandNo>=7 && strstr(header->basic->satName,"Himawari")!=NULL ) ||
		(bandNo>=2 && strstr(header->basic->satName,"MTSAT-2") !=NULL ) ){
		if( (1>fwrite(&header->calib->rad2btp_c0,8,1,fp)) ||
			(1>fwrite(&header->calib->rad2btp_c1,8,1,fp)) ||
			(1>fwrite(&header->calib->rad2btp_c2,8,1,fp)) ||
			(1>fwrite(&header->calib->btp2rad_c0,8,1,fp)) ||
			(1>fwrite(&header->calib->btp2rad_c1,8,1,fp)) ||
			(1>fwrite(&header->calib->btp2rad_c2,8,1,fp)) ||
			(1>fwrite(&header->calib->lightSpeed,8,1,fp)) ||
			(1>fwrite(&header->calib->planckConst,8,1,fp)) ||
			(1>fwrite(&header->calib->bolzConst,8,1,fp)) ||
			(1>fwrite(&header->calib->spare,40,1,fp)) ){
			fprintf(stderr,"header #5 write error\n");
			return(ERROR_WRITE);
		}
	}else{
		if( (1>fwrite(&header->calib->rad2albedo,8,1,fp)) ||
			(1>fwrite(&header->calib->spareV,104,1,fp))){
			fprintf(stderr,"header #5 write error\n");
			return(ERROR_WRITE);
		}
	}
	/* #6 */
	version = atof(header->basic->verName);
	/* for version 1.2 */
	if(version >  1.1){
		if( (1>fwrite(&header->interCalib->HeaderNum,1,1,fp)) ||
			(1>fwrite(&header->interCalib->BlockLen,2,1,fp)) ||
			(1>fwrite(&header->interCalib->gsicsCorr_C,8,1,fp)) ||
			(1>fwrite(&header->interCalib->gsicsCorr_1,8,1,fp)) ||
			(1>fwrite(&header->interCalib->gsicsCorr_2,8,1,fp)) ||
			(1>fwrite(&header->interCalib->gsicsBias,8,1,fp)) ||
			(1>fwrite(&header->interCalib->gsicsUncert,8,1,fp)) ||
			(1>fwrite(&header->interCalib->gsicsStscene,8,1,fp)) ||
			(1>fwrite(&header->interCalib->gsicsCorr_StrMJD,8,1,fp)) ||
			(1>fwrite(&header->interCalib->gsicsCorr_EndMJD,8,1,fp)) ||
			(1>fwrite(&header->interCalib->gsicsCorrInfo,1,64,fp)) ||
			(1>fwrite(&header->interCalib->spare,1,128,fp)) ){
			fprintf(stderr,"header #6 write error\n");
			return(ERROR_WRITE);
		}
	}else if(version >  1.0){
		/* for version 1.1 */
		if( (1>fwrite(&header->interCalib->HeaderNum,1,1,fp)) ||
			(1>fwrite(&header->interCalib->BlockLen,2,1,fp)) ||
			(1>fwrite(&header->interCalib->gsicsCorr_C,8,1,fp)) ||
			(1>fwrite(&header->interCalib->gsicsCorr_C_er,8,1,fp)) ||
			(1>fwrite(&header->interCalib->gsicsCorr_1,8,1,fp)) ||
			(1>fwrite(&header->interCalib->gsicsCorr_1_er,8,1,fp)) ||
			(1>fwrite(&header->interCalib->gsicsCorr_2,8,1,fp)) ||
			(1>fwrite(&header->interCalib->gsicsCorr_2_er,8,1,fp)) ||
			(1>fwrite(&header->interCalib->gsicsCorr_StrMJD,8,1,fp)) ||
			(1>fwrite(&header->interCalib->gsicsCorr_EndMJD,8,1,fp)) ||
			(1>fwrite(&header->interCalib->gsicsCorrInfo,1,64,fp)) ||
			(1>fwrite(&header->interCalib->spare,1,128,fp)) ){
			fprintf(stderr,"header #6 write error\n");
			return(ERROR_WRITE);
		}
	}else{
		/* for version 1.0 and 0.0 */
		if( (1>fwrite(&header->interCalib->HeaderNum,1,1,fp)) ||
			(1>fwrite(&header->interCalib->BlockLen,2,1,fp)) ||
			(1>fwrite(&header->interCalib->gsicsCorr_C,8,1,fp)) ||
			(1>fwrite(&header->interCalib->gsicsCorr_C_er,8,1,fp)) ||
			(1>fwrite(&header->interCalib->gsicsCorr_1,8,1,fp)) ||
			(1>fwrite(&header->interCalib->gsicsCorr_1_er,8,1,fp)) ||
			(1>fwrite(&header->interCalib->gsicsCorr_2,8,1,fp)) ||
			(1>fwrite(&header->interCalib->gsicsCorr_2_er,8,1,fp)) ||
			(1>fwrite(&header->interCalib->gsicsCorr_StrMJD,8,1,fp)) ||
			(1>fwrite(&header->interCalib->gsicsCorr_EndMJD,8,1,fp)) ||
			(1>fwrite(&header->interCalib->gsicsCorrInfo,1,64,fp)) ||
			(1>fwrite(&header->interCalib->spare,1,128,fp)) ){
			fprintf(stderr,"header #6 write error\n");
			return(ERROR_WRITE);
		}
	}
	/* #7 */
	if( (1>fwrite(&header->seg->HeaderNum,1,1,fp)) ||
		(1>fwrite(&header->seg->BlockLen,2,1,fp)) ||
		(1>fwrite(&header->seg->totalSegNum,1,1,fp)) ||
		(1>fwrite(&header->seg->segSeqNo,1,1,fp)) ||
		(1>fwrite(&header->seg->strLineNo,2,1,fp)) ||
		(1>fwrite(&header->seg->spare,40,1,fp)) ){
		fprintf(stderr,"header #7 write error\n");
		return(ERROR_WRITE);
	}
	/* #8 */
	if( (1>fwrite(&header->navcorr->HeaderNum,1,1,fp)) ||
		(1>fwrite(&header->navcorr->BlockLen,2,1,fp)) ||
		(1>fwrite(&header->navcorr->RoCenterColumn,4,1,fp)) ||
		(1>fwrite(&header->navcorr->RoCenterLine,4,1,fp)) ||
		(1>fwrite(&header->navcorr->RoCorrection,8,1,fp)) ||
		(1>fwrite(&header->navcorr->correctNum,2,1,fp)) ){
		fprintf(stderr,"header #8 write error\n");
		return(ERROR_WRITE);
	}
	for(ii=0;ii<correctNum;ii++){
		if( (1>fwrite(&header->navcorr->lineNo[ii],2,1,fp)) ||
			(1>fwrite(&header->navcorr->columnShift[ii],4,1,fp)) ||
			(1>fwrite(&header->navcorr->lineShift[ii],4,1,fp)) ){
			fprintf(stderr,"header #8 write error\n");
			return(ERROR_WRITE);
		}
	}
	if( (1>fwrite(&header->navcorr->spare,40,1,fp))){
		fprintf(stderr,"header #8 write error\n");
		return(ERROR_WRITE);
	}
	/* #9 */
	if( (1>fwrite(&header->obstime->HeaderNum,1,1,fp)) ||
		(1>fwrite(&header->obstime->BlockLen,2,1,fp)) ||
		(1>fwrite(&header->obstime->obsNum,2,1,fp)) ){
		fprintf(stderr,"header #9 write error\n");
		return(ERROR_WRITE);
	}
	for(ii=0;ii<obsNum;ii++){
		if( (1>fwrite(&header->obstime->lineNo[ii],2,1,fp)) ||
			(1>fwrite(&header->obstime->obsMJD[ii],8,1,fp)) ){
			fprintf(stderr,"header #9 write error\n");
			return(ERROR_WRITE);
		}
	}
	if( (1>fwrite(&header->obstime->spare,40,1,fp)) ){
		fprintf(stderr,"header #9 write error\n");
		return(ERROR_WRITE);
	}
	/* #10*/
	if( (1>fwrite(&header->error->HeaderNum,1,1,fp)) ||
		(1>fwrite(&header->error->BlockLen,4,1,fp)) ||
		(1>fwrite(&header->error->errorNum,2,1,fp)) ){
		fprintf(stderr,"header #10 write error\n");
		return(ERROR_WRITE);
	}
	for(ii=0;ii<errorNum;ii++){
		if( (1>fwrite(&header->error->lineNo[ii],2,1,fp)) ||
			(1>fwrite(&header->error->errPixNum[ii],2,1,fp)) ){
			fprintf(stderr,"header #10 write error\n");
			return(ERROR_WRITE);
		}
	}
	if( (1>fwrite(&header->error->spare,40,1,fp)) ){
		fprintf(stderr,"header #10 write error\n");
		return(ERROR_WRITE);
	}
	/* #11*/
	if( (1>fwrite(&header->spare->HeaderNum,1,1,fp)) ||
		(1>fwrite(&header->spare->BlockLen,2,1,fp)) ||
		(1>fwrite(&header->spare->spare,256,1,fp)) ){
		fprintf(stderr,"header #11 write error\n");
		return(ERROR_WRITE);
	}
	// 4 byte swap
	if(byteSwap==1){
		hisd_swap_header(header,correctNum,obsNum,errorNum,bandNo);
	}
	return(NORMAL_END);
}

/* --------------------------------------------------------------------------
 *	hisd_swap_header()
 --------------------------------------------------------------------------*/
void hisd_swap_header(HisdHeader *header, 
	unsigned short correctNum,unsigned short obsNum,
	unsigned short errorNum,unsigned short bandNo){
	/* #1 */
	swapBytes(&header->basic->BlockLen,2,1);
	swapBytes(&header->basic->headerNum,2,1);
	swapBytes(&header->basic->TimeLine,2,1);
	swapBytes(&header->basic->ObsStartTime,8,1);
	swapBytes(&header->basic->ObsEndTime,8,1);
	swapBytes(&header->basic->fileCreationMjd,8,1);
	swapBytes(&header->basic->totalHeaderLen,4,1);
	swapBytes(&header->basic->dataLen,4,1);
	/* #2 */
	swapBytes(&header->data->BlockLen,2,1);
	swapBytes(&header->data->bitPix,2,1);
	swapBytes(&header->data->nPix,2,1);
	swapBytes(&header->data->nLin,2,1);
	/* #3 */
	swapBytes(&header->proj->BlockLen,2,1);
	swapBytes(&header->proj->subLon,8,1);
	swapBytes(&header->proj->cfac,4,1);
	swapBytes(&header->proj->lfac,4,1);
	swapBytes(&header->proj->coff,4,1);
	swapBytes(&header->proj->loff,4,1);
	swapBytes(&header->proj->satDis,8,1);
	swapBytes(&header->proj->eqtrRadius,8,1);
	swapBytes(&header->proj->polrRadius,8,1);
	swapBytes(&header->proj->projParam1,8,1);
	swapBytes(&header->proj->projParam2,8,1);
	swapBytes(&header->proj->projParam3,8,1);
	swapBytes(&header->proj->projParamSd,8,1);
	swapBytes(&header->proj->resampleKind,2,1);
	swapBytes(&header->proj->resampleSize,2,1);
	/* #4 */
	swapBytes(&header->nav->BlockLen,2,1);
	swapBytes(&header->nav->navMjd,8,1);
	swapBytes(&header->nav->sspLon,8,1);
	swapBytes(&header->nav->sspLat,8,1);
	swapBytes(&header->nav->satDis,8,1);
	swapBytes(&header->nav->nadirLon,8,1);
	swapBytes(&header->nav->nadirLat,8,1);
	swapBytes(&header->nav->sunPos_x,8,1);
	swapBytes(&header->nav->sunPos_y,8,1);
	swapBytes(&header->nav->sunPos_z,8,1);
	swapBytes(&header->nav->moonPos_x,8,1);
	swapBytes(&header->nav->moonPos_y,8,1);
	swapBytes(&header->nav->moonPos_z,8,1);
	/* #5 */
	swapBytes(&header->calib->BlockLen,2,1);
	swapBytes(&header->calib->bandNo,2,1);
	swapBytes(&header->calib->waveLen,8,1);
	swapBytes(&header->calib->bitPix,2,1);
	swapBytes(&header->calib->errorCount,2,1);
	swapBytes(&header->calib->outCount,2,1);
	swapBytes(&header->calib->gain_cnt2rad,8,1);
	swapBytes(&header->calib->cnst_cnt2rad,8,1);
	if( (bandNo>=7 && strstr(header->basic->satName,"Himawari")!=NULL ) ||
		(bandNo>=2 && strstr(header->basic->satName,"MTSAT-2") !=NULL )  ){
		swapBytes(&header->calib->rad2btp_c0,8,1);
		swapBytes(&header->calib->rad2btp_c1,8,1);
		swapBytes(&header->calib->rad2btp_c2,8,1);
		swapBytes(&header->calib->btp2rad_c0,8,1);
		swapBytes(&header->calib->btp2rad_c1,8,1);
		swapBytes(&header->calib->btp2rad_c2,8,1);
		swapBytes(&header->calib->lightSpeed,8,1);
		swapBytes(&header->calib->planckConst,8,1);
		swapBytes(&header->calib->bolzConst,8,1);
	}else{
		swapBytes(&header->calib->rad2albedo,8,1);
	}
	/* #6 */
	swapBytes(&header->interCalib->BlockLen,2,1);
	swapBytes(&header->interCalib->gsicsCorr_C,8,1);
	swapBytes(&header->interCalib->gsicsCorr_1,8,1);
	swapBytes(&header->interCalib->gsicsCorr_2,8,1);
	swapBytes(&header->interCalib->gsicsCorr_StrMJD,8,1);
	swapBytes(&header->interCalib->gsicsCorr_EndMJD,8,1);
	swapBytes(&header->interCalib->gsicsUpperLimit,4,1);
	swapBytes(&header->interCalib->gsicsLowerLimit,4,1);
	/* for version 1.0 and 1.1 */
	swapBytes(&header->interCalib->gsicsCorr_C_er,8,1);
	swapBytes(&header->interCalib->gsicsCorr_1_er,8,1);
	swapBytes(&header->interCalib->gsicsCorr_2_er,8,1);
	/* for version 1.2 */
	swapBytes(&header->interCalib->gsicsBias,8,1);
	swapBytes(&header->interCalib->gsicsUncert,8,1);
	swapBytes(&header->interCalib->gsicsStscene,8,1);
	/* #7 */
	swapBytes(&header->seg->BlockLen,2,1);
	swapBytes(&header->seg->strLineNo,2,1);
	/* #8 */
	swapBytes(&header->navcorr->BlockLen,2,1);
	swapBytes(&header->navcorr->RoCenterColumn,4,1);
	swapBytes(&header->navcorr->RoCenterLine,4,1);
	swapBytes(&header->navcorr->RoCorrection,8,1);
	swapBytes(&header->navcorr->correctNum,2,1);
	swapBytes(&header->navcorr->lineNo[0],2,correctNum);
	swapBytes(&header->navcorr->columnShift[0],4,correctNum);
	swapBytes(&header->navcorr->lineShift[0],4,correctNum);
	/* #9 */
	swapBytes(&header->obstime->BlockLen,2,1);
	swapBytes(&header->obstime->obsNum,2,1);
	swapBytes(&header->obstime->lineNo[0],2,obsNum);
	swapBytes(&header->obstime->obsMJD[0],8,obsNum);
	/* #10 */
	swapBytes(&header->error->BlockLen,4,1);
	swapBytes(&header->error->errorNum,2,1);
	swapBytes(&header->error->lineNo[0],2,errorNum);
	swapBytes(&header->error->errPixNum[0],2,errorNum);
	/* #11 */
	swapBytes(&header->spare->BlockLen,2,1);
}

/* ---------------------------------------------------------------------------
  write_data()
 -----------------------------------------------------------------------------*/
int write_data(unsigned short *data, const int num, FILE *fp, 
	const char byteOrder_flag){
	char byteSwap=0;
	// 1 check byte order
	if(byteOrder() == byteOrder_flag ){
		byteSwap=0;
	}else{
		byteSwap=1;
	}
	// 2 byte swap
	if(byteSwap == 1){
		swapBytes(&data[0],2,num);
	}
	// 3 write data block
	if( num > fwrite(data,sizeof(unsigned short),num,fp)){
		fprintf(stderr,"data write error\n");
		return(ERROR_WRITE);
	}
	//
	return(NORMAL_END);
}

