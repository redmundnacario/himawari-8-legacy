This sample program converts the Himawari Standard Data resolution from 0.5km to 1km, from 1km to 2km,
from 2km to 4km, and from 4km to 8km by sub-sampling.
It has been compiled and checked on Linux (RedHat, 64bit).
We would appreciate it if you could give us some comments or/and bug reports (E-mail: calmstr@dpc.kishou.go.jp).

Files:
    hisd.h         - define the structure of the header of the Himawari Standard Data
    downsample.h   - header file for main function
    date_utl.h     - header file for MJD function
    main.c         - main function
    hisd_read.c    - function for reading the Himawari Standard Data
    hisd_utl.c     - function for making the Himawari Standard Data
    date_utl.c     - function for Modified Julian Day


Make/Run
    (1) extract zip file        (>unzip sample_codes_down.zip)
    (2) make executable file    (>make                       )
    (3) run the file            (>downsample SampleFileName  )

Note:
    Output filename convention
        HS_aaa_yyyymmdd_hhnn_Bbb_cccc_Rjj_Skkll.DAT

        aaa  : Satellite name
        yyyy : Observation start time (timeline) [year] (4 digits)
        mm   : Observation start time (timeline) [month] (01-12)
        dd   : Observation start time (timeline) [day]   (01-31)
        hh   : Observation start time (timeline) [hour]  (00-23)
        nn   : Observation start time (timeline) [min.]
        bb   : Band number
        cccc : Observation area and number
        jj   : Spatial resolution at SSP
                 input 05  ==> outpuf 10
                 input 10  ==> outpuf 20
                 input 20  ==> outpuf 40
        kkll : Infomation on the segment division of Himawari Standard Data

Detail of Himawari Standard Format:
    For data structure of Himawari Standard Format, please refer to MSC
    website and Himawari Standard Data User's Guide.

    MSC website
    http://www.jma-net.go.jp/msc/en/

    Himawari Standard Data User's Guide
    http://www.data.jma.go.jp/mscweb/en/himawari89/space_segment/hsd_sample/HS_D_users_guide_en.pdf

History
    March,  2015  First release
    May,    2015  Change for version 1.2
    June,   2015  Version 2015-06
                  Changed the default "byte order" (downsample.h)
                  Fixed bug in function hisd_read_header() (hisd_read.c)
