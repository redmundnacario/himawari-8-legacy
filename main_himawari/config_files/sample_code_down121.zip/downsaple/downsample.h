/* ----------------------------------------------------------------------------
	Sample source code for Himawari Satandard Data

	Copyright (C) 2015 MSC (Meteorological Satellite Center) of JMA

	Disclaimer:
		MSC does not guarantee regarding the correctness, accuracy, reliability,
		or any other aspect regarding use of these sample codes.

	Detail of Himawari Standard Format:
		For data structure of Himawari Standard Format, prelese refer to MSC
		Website and Himawari Standard Data User's Guide.

		MSC Website
		http://www.jma-net.go.jp/msc/en/

		Himawari Standard Data User's Guide
		http://www.data.jma.go.jp/mscweb/en/himawari89/space_segment/hsd_sample/HS_D_users_guide_en.pdf

	History
		March,   2015  First release
        June,    2015  Changed the default "byte order"

---------------------------------------------------------------------------- */

# define  NORMAL_END   0
# define  ERROR_ARG         1
# define  ERROR_FILE_OPEN   2
# define  ERROR_CALLOCATE   3
# define  ERROR_READ_HEADER 4
# define  ERROR_READ_DATA   6
# define  ERROR_PARAMETER   7
# define  ERROR_MAKE_HEADER 8
# define  ERROR_MAKE_DATA   9
# define  ERROR_WRITE       10

/* June, 2015    Changed the default "byte order" */
//# define  ENDIAN 1  // 0: little endian  1: big endian
# define  ENDIAN 0

# define  HISD_CFAC_05    81865099  /* 0.5 km */
# define  HISD_CFAC_10    40932549  /*  1  km */
# define  HISD_CFAC_20    20466275  /*  2  km */
# define  HISD_CFAC_40    10233137  /*  4  km */
# define  HISD_CFAC_80     5116569  /*  8  km */ /* June, 2015 */
# define  HISD_CFAC_160    2558284  /* 16  km */ /* June, 2015 */
# define  HISD_CFAC_320    1279142  /* 32  km */ /* June, 2015 */
# define  HISD_CFAC_640     639571  /* 64  km */ /* June, 2015 */

int make_hisd_header(HisdHeader *hisd_o, HisdHeader *hisd_d);
int make_hisd_data(HisdHeader *hisd_o, HisdHeader *hisd_d,
	unsigned short *data_o, unsigned short *data_d);
int make_hisd_errorinfo(HisdHeader *head_d,unsigned short *data_d);
int write_hisd_header(HisdHeader *header, FILE *fp, const char byteOrder_flag);
void hisd_swap_header(HisdHeader *header,
	unsigned short correctNum,unsigned short obsNum,
	unsigned short errorNum,unsigned short bandNo);
int write_data(unsigned short *data, const int num, FILE *fp,
    const char byteOrder_flag);
